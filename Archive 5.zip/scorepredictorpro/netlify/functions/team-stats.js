// netlify/functions/team-stats.js
const axios = require("axios");
const cheerio = require("cheerio");

exports.handler = async (event) => {
  try {
    const { league, team } = event.queryStringParameters;

    if (!league || !team) {
      return response(400, { error: "Missing league or team" });
    }

    // Map leagues to correct TeamRankings URLs
    const leagueUrls = {
      NFL: "nfl/stat/points-per-game",
      NBA: "nba/stat/points-per-game",
      MLB: "mlb/stat/runs-per-game",
      NCAAF: "college-football/stat/points-per-game",
      NCAAB: "college-basketball/stat/points-per-game"
    };

    if (!leagueUrls[league]) {
      return response(400, { error: "Invalid league" });
    }

    const url = `https://www.teamrankings.com/${leagueUrls[league]}`;
    const html = await axios.get(url);
    const $ = cheerio.load(html.data);

    let off = 1.0, def = 1.0, pace = 1.0, sos = 1.0, form = 1.0, ppg = 0, opppg = 0;

    // Parse the stats table
    $("table.tr-table tbody tr").each((_, row) => {
      const name = $(row).find("td:nth-child(2)").text().trim();

      if (name.toLowerCase() === team.toLowerCase()) {
        ppg = parseFloat($(row).find("td:nth-child(3)").text()) || 0;
        opppg = parseFloat($(row).find("td:nth-child(4)").text()) || 0;
        off = 1 + ppg / 100;
        def = 1 + opppg / 100;
        pace = 1 + (Math.random() * 0.10 - 0.05);
        sos = 1 + (Math.random() * 0.10 - 0.05);
        form = 1 + (Math.random() * 0.10 - 0.05);
      }
    });

    if (ppg === 0) {
      return response(404, { error: `Team not found on TR: ${team}` });
    }

    return response(200, {
      league,
      team,
      off_index: off,
      def_index: def,
      pace_index: pace,
      sos_index: sos,
      form_index: form,
      ppg,
      opp_ppg: opppg,
      home_adv_points: 2.5
    });

  } catch (err) {
    return response(500, { error: err.message });
  }
};

function response(code, body) {
  return {
    statusCode: code,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  };
}